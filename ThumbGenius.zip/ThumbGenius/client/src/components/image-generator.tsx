import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface GeneratedImage {
  url: string;
  model: string;
  id: string;
  isFavorite?: boolean;
}

interface GenerationResult {
  id: string;
  images: GeneratedImage[];
  generationTime: number;
  selectedModel: string;
  reasoning: string;
}

interface UsageData {
  generationsLeft: number;
  generationCount: number;
}

// Component for reliable image loading with retry and fallback
interface ImageWithFallbackProps {
  src: string;
  alt: string;
  className: string;
  index: number;
  onClick?: () => void;
}

const ImageWithFallback = ({ src, alt, className, index, onClick }: ImageWithFallbackProps) => {
  const [imageState, setImageState] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [retryCount, setRetryCount] = useState(0);
  const [currentSrc, setCurrentSrc] = useState(src);
  
  // Clean up blob URLs to prevent memory leaks
  useEffect(() => {
    return () => {
      if (currentSrc && currentSrc.startsWith('blob:')) {
        URL.revokeObjectURL(currentSrc);
      }
    };
  }, [currentSrc]);
  
  // Reset state when src prop changes
  useEffect(() => {
    setImageState('loading');
    setRetryCount(0);
    setCurrentSrc(src);
  }, [src]);

  const handleImageLoad = () => {
    setImageState('loaded');
    console.log('Image loaded successfully:', currentSrc);
  };

  const handleImageError = () => {
    if (retryCount < 3) {
      // Reduced retries from 5 to 3, shorter delays
      setTimeout(() => {
        setRetryCount(prev => prev + 1);
        const newSrc = `${src}&retry=${Date.now()}&attempt=${retryCount + 1}`;
        setCurrentSrc(newSrc);
        console.log(`Retrying image load (${retryCount + 1}/3):`, newSrc);
      }, 2000); // Wait 2 seconds between retries
    } else {
      setImageState('error');
      console.error('Image failed to load after 3 retries:', src);
    }
  };

  return (
    <div className={`relative ${className}`}>
      {imageState === 'loading' && (
        <div className="absolute inset-0 bg-gray-100 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-main mx-auto mb-2"></div>
            <p className="text-sm text-gray-500">Loading image {index + 1}...</p>
            {retryCount > 0 && (
              <p className="text-xs text-gray-400 mt-1">Retry {retryCount}/3</p>
            )}
          </div>
        </div>
      )}
      
      {imageState === 'error' && (
        <div className="absolute inset-0 bg-gray-100 rounded-lg flex items-center justify-center border-2 border-dashed border-gray-300">
          <div className="text-center p-4">
            <i className="fas fa-exclamation-triangle text-3xl text-gray-400 mb-2"></i>
            <p className="text-sm text-gray-500 mb-2">Image {index + 1} failed to load</p>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setImageState('loading');
                setRetryCount(0);
                const newSrc = `${src}&manual=${Date.now()}`;
                setCurrentSrc(newSrc);
              }}
            >
              <i className="fas fa-redo mr-2"></i>
              Retry
            </Button>
          </div>
        </div>
      )}
      
      <img
        src={currentSrc}
        alt={alt}
        className={`${className} ${imageState === 'loaded' ? 'opacity-100 cursor-pointer hover:opacity-90' : 'opacity-0'}`}
        crossOrigin="anonymous"
        referrerPolicy="no-referrer"
        onLoad={handleImageLoad}
        onError={handleImageError}
        onClick={() => imageState === 'loaded' && onClick?.()}
        style={{ transition: 'opacity 0.3s ease-in-out' }}
      />
    </div>
  );
};

export function ImageGenerator() {
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("photorealistic");
  const [aspectRatio, setAspectRatio] = useState("16:9");
  const [imageCount, setImageCount] = useState(5);
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
  const [results, setResults] = useState<GeneratedImage[]>([]);
  const [favorites, setFavorites] = useState<GeneratedImage[]>([]);
  const [showGallery, setShowGallery] = useState(false);
  const { toast } = useToast();

  const today = new Date().toISOString().split('T')[0];
  
  const { data: usage } = useQuery<UsageData>({
    queryKey: ['/api/usage', today],
    refetchInterval: 60000,
  });

  const generateImageMutation = useMutation({
    mutationFn: async (data: { prompt: string; style: string; aspectRatio: string; imageCount: number }) => {
      const response = await apiRequest('POST', '/api/generate-thumbnail', data);
      return response.json();
    },
    onSuccess: (data: GenerationResult) => {
      const imagesWithIds = data.images.map((img, index) => ({
        ...img,
        id: `${Date.now()}-${index}`,
        isFavorite: false
      }));
      setResults(prevResults => [...prevResults, ...imagesWithIds]);
      queryClient.invalidateQueries({ queryKey: ['/api/usage'] });
      toast({
        title: "Success!",
        description: `Generated ${data.images.length} new images in ${data.generationTime}s`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleGenerate = () => {
    if (!prompt.trim()) {
      toast({
        title: "Missing Prompt",
        description: "Please describe your image before generating.",
        variant: "destructive",
      });
      return;
    }

    setResults([]);
    generateImageMutation.mutate({ prompt, style, aspectRatio, imageCount });
  };

  const handleGenerateMore = () => {
    if (!prompt.trim()) {
      toast({
        title: "Missing Prompt", 
        description: "Please describe your image before generating.",
        variant: "destructive",
      });
      return;
    }

    generateImageMutation.mutate({ prompt, style, aspectRatio, imageCount });
  };

  const toggleFavorite = (imageId: string) => {
    const imageToToggle = results.find(img => img.id === imageId);
    if (!imageToToggle) return;

    if (imageToToggle.isFavorite) {
      setFavorites(prev => prev.filter(fav => fav.id !== imageId));
      setResults(prev => prev.map(img => 
        img.id === imageId ? { ...img, isFavorite: false } : img
      ));
      toast({
        title: "Removed from Favorites",
        description: "Image removed from your gallery",
      });
    } else {
      const favoriteImage = { ...imageToToggle, isFavorite: true };
      setFavorites(prev => [...prev, favoriteImage]);
      setResults(prev => prev.map(img => 
        img.id === imageId ? { ...img, isFavorite: true } : img
      ));
      toast({
        title: "Added to Favorites", 
        description: "Image saved to your gallery",
      });
    }
  };

  const handleDownload = async (imageUrl: string, index: number) => {
    try {
      const response = await fetch(imageUrl, { mode: 'cors' });
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `xeonz-image-${index + 1}.jpg`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Download Complete",
        description: "Your image has been downloaded successfully.",
      });
    } catch (error) {
      window.open(imageUrl, '_blank');
      toast({
        title: "Download Started",
        description: "Image opened in new tab for manual download.",
      });
    }
  };

  const styleOptions = [
    { id: "photorealistic", icon: "fas fa-camera", label: "Photorealistic", description: "Realistic photos" },
    { id: "artistic", icon: "fas fa-palette", label: "Artistic", description: "Illustrations and art" },
    { id: "typography", icon: "fas fa-font", label: "Typography", description: "Text-focused designs" },
    { id: "abstract", icon: "fas fa-shapes", label: "Abstract", description: "Geometric and modern" },
  ];

  const aspectRatioOptions = [
    { id: "16:9", label: "16:9 (Widescreen)" },
    { id: "1:1", label: "1:1 (Square)" },
    { id: "4:3", label: "4:3 (Standard)" },
  ];

  return (
    <section className="py-12" id="gallery">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-main to-blue-main bg-clip-text text-transparent mb-4">
            Xeonz Image Gen
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-6">
            Create stunning, professional images with the power of AI. Transform your ideas into beautiful visuals instantly.
          </p>
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setShowGallery(false)}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                !showGallery
                  ? "bg-purple-main text-white"
                  : "bg-white text-gray-700 border border-gray-300 hover:border-purple-main"
              }`}
              data-testid="button-generate"
            >
              Generate Images
            </button>
            <button
              onClick={() => setShowGallery(true)}
              className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                showGallery
                  ? "bg-purple-main text-white"
                  : "bg-white text-gray-700 border border-gray-300 hover:border-purple-main"
              }`}
              data-testid="button-gallery"
            >
              Gallery ({favorites.length})
            </button>
          </div>
        </div>

        {showGallery ? (
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Favorite Images</h2>
            {favorites.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-heart text-gray-400 text-3xl"></i>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">No Favorites Yet</h4>
                <p className="text-gray-600">Start generating images and add them to your favorites!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {favorites.map((image, index) => (
                  <div key={image.id} className="relative group">
                    <img
                      src={image.url}
                      alt={`Favorite image ${index + 1}`}
                      className="w-full aspect-square object-cover rounded-lg shadow-md"
                      crossOrigin="anonymous"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <div className="flex space-x-3">
                        <button
                          onClick={() => handleDownload(image.url, index)}
                          className="bg-white text-gray-900 hover:bg-gray-100 px-4 py-2 rounded-lg font-medium"
                          data-testid={`button-download-${image.id}`}
                        >
                          <i className="fas fa-download mr-2"></i>
                          Download
                        </button>
                        <button
                          onClick={() => toggleFavorite(image.id)}
                          className="bg-red-500 text-white hover:bg-red-600 px-4 py-2 rounded-lg font-medium"
                          data-testid={`button-remove-favorite-${image.id}`}
                        >
                          <i className="fas fa-heart-broken mr-2"></i>
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Generate Your Image</h2>
            
            <div className="mb-6">
              <Label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">
                Describe your image
              </Label>
              <Textarea
                id="prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-32 resize-none"
                placeholder="e.g., A beautiful mountain landscape at sunset with vibrant colors, detailed and photorealistic..."
                maxLength={5000}
                data-testid="input-prompt"
              />
              <div className="mt-2 flex justify-between items-center">
                <span className="text-sm text-gray-500">Be specific for better results</span>
                <span className="text-sm text-gray-400">
                  {prompt.length}/5000
                </span>
              </div>
            </div>

            <div className="mb-6">
              <Label className="block text-sm font-medium text-gray-700 mb-3">Style Preference</Label>
              <div className="grid grid-cols-2 gap-3">
                {styleOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setStyle(option.id)}
                    className={`p-3 border-2 rounded-lg text-left transition-colors ${
                      style === option.id
                        ? "border-purple-main bg-purple-50"
                        : "border-gray-200 hover:border-purple-main hover:bg-purple-50"
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <i className={`${option.icon} ${style === option.id ? "text-purple-main" : "text-gray-600"}`}></i>
                      <span className={`font-medium ${style === option.id ? "text-purple-main" : "text-gray-900"}`}>
                        {option.label}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{option.description}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <Label className="block text-sm font-medium text-gray-700 mb-3">Aspect Ratio</Label>
              <div className="flex flex-wrap gap-2">
                {aspectRatioOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setAspectRatio(option.id)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                      aspectRatio === option.id
                        ? "bg-purple-main text-white"
                        : "border border-gray-300 text-gray-700 hover:border-purple-main hover:text-purple-main"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <Label className="block text-sm font-medium text-gray-700 mb-3">
                Number of Images ({imageCount})
              </Label>
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-500">1</span>
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={imageCount}
                  onChange={(e) => setImageCount(parseInt(e.target.value))}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  style={{
                    background: `linear-gradient(to right, #8B5CF6 0%, #8B5CF6 ${(imageCount - 1) * 11.11}%, #E5E7EB ${(imageCount - 1) * 11.11}%, #E5E7EB 100%)`
                  }}
                  data-testid="slider-image-count"
                />
                <span className="text-sm text-gray-500">10</span>
              </div>
              <div className="mt-2 text-center">
                <span className="text-sm text-purple-main font-medium">
                  Generate {imageCount} image{imageCount !== 1 ? 's' : ''} per request
                </span>
              </div>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generateImageMutation.isPending || !prompt.trim()}
              className="w-full bg-gradient-to-r from-purple-main to-blue-main text-white py-4 rounded-lg font-semibold text-lg hover:opacity-90 transition-opacity"
              data-testid="button-generate-images"
            >
              {generateImageMutation.isPending ? (
                <>
                  <i className="fas fa-spinner animate-spin mr-2"></i>
                  Generating...
                </>
              ) : (
                <>
                  <i className="fas fa-magic mr-2"></i>
                  Generate {imageCount} Image{imageCount !== 1 ? 's' : ''}
                </>
              )}
            </Button>

            <div className="mt-4 text-center text-sm text-gray-500">
              <i className="fas fa-infinity mr-1"></i>
              <span>Unlimited free generations available</span>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Generated Images</h3>
              {results.length > 0 && (
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <i className="fas fa-clock"></i>
                  <span>Generated in {generateImageMutation.data?.generationTime || 0}s</span>
                </div>
              )}
            </div>

            {generateImageMutation.isPending && (
              <div className="text-center py-12">
                <div className="aspect-video bg-gray-100 rounded-lg flex flex-col items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-main mb-4"></div>
                  <p className="text-gray-600 font-medium mb-2">Generating your images...</p>
                  <p className="text-sm text-gray-500">This may take up to 30 seconds</p>
                </div>
              </div>
            )}

            {!generateImageMutation.isPending && results.length > 0 && (
              <div className="space-y-6">
                <div className={`grid gap-4 ${
                  results.length === 1 
                    ? 'grid-cols-1' 
                    : results.length === 2 
                    ? 'grid-cols-1 md:grid-cols-2' 
                    : results.length <= 4 
                    ? 'grid-cols-1 md:grid-cols-2' 
                    : results.length <= 6
                    ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
                    : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
                }`}>
                  {results.map((result, index) => (
                    <div key={result.id} className="relative group">
                      <ImageWithFallback
                        src={result.url}
                        alt={`Generated image ${index + 1}`}
                        className="w-full aspect-video object-cover rounded-lg shadow-md"
                        index={index}
                        onClick={() => setFullscreenImage(result.url)}
                      />
                      
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-opacity rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <div className="flex space-x-3">
                          <Button
                            onClick={() => handleDownload(result.url, index)}
                            className="bg-white text-gray-900 hover:bg-gray-100"
                            data-testid={`button-download-${result.id}`}
                          >
                            <i className="fas fa-download mr-2"></i>
                            Download
                          </Button>
                          <Button
                            onClick={() => toggleFavorite(result.id)}
                            className={`${result.isFavorite ? 'bg-red-500 hover:bg-red-600' : 'bg-white hover:bg-gray-100'} text-${result.isFavorite ? 'white' : 'gray-900'}`}
                            data-testid={`button-favorite-${result.id}`}
                          >
                            <i className={`fas fa-heart mr-2 ${result.isFavorite ? 'text-white' : 'text-red-500'}`}></i>
                            {result.isFavorite ? 'Favorited' : 'Favorite'}
                          </Button>
                        </div>
                      </div>

                      <div className="absolute top-3 right-3 bg-purple-main text-white px-2 py-1 rounded-full text-xs font-medium">
                        <span>{result.model}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={handleGenerateMore}
                  disabled={generateImageMutation.isPending}
                  className="w-full border-2 border-dashed border-gray-300 rounded-lg py-8 text-gray-500 hover:border-purple-main hover:text-purple-main transition-colors flex flex-col items-center space-y-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  data-testid="button-generate-more"
                >
                  <i className="fas fa-plus text-2xl"></i>
                  <span className="font-medium">Generate {imageCount} More Images</span>
                </button>
              </div>
            )}

            {!generateImageMutation.isPending && results.length === 0 && (
              <div className="text-center py-12">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-image text-gray-400 text-3xl"></i>
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Ready to Create</h4>
                <p className="text-gray-600">Fill out the form and click generate to see your images here</p>
              </div>
            )}
          </div>
        </div>
        )}
      </div>

      {/* Fullscreen Image Modal */}
      {fullscreenImage && (
        <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4"
             onClick={() => setFullscreenImage(null)}>
          <div className="relative max-w-full max-h-full">
            <button
              onClick={() => setFullscreenImage(null)}
              className="absolute top-4 right-4 text-white text-2xl hover:text-gray-300 z-10"
              data-testid="button-close-fullscreen"
            >
              <i className="fas fa-times"></i>
            </button>
            <img
              src={fullscreenImage}
              alt="Fullscreen view"
              className="max-w-full max-h-[90vh] object-contain rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-white text-sm bg-black bg-opacity-50 px-3 py-1 rounded">
              Click anywhere to close
            </div>
          </div>
        </div>
      )}
    </section>
  );
}