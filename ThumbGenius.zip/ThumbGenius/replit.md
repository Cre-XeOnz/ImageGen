# ThumbnailAI - AI-Powered Thumbnail Generator

## Overview

ThumbnailAI is a full-stack web application that generates professional thumbnails using AI models. The application intelligently analyzes user prompts and automatically selects the optimal AI model (DALL-E 3, Midjourney, or Stable Diffusion) for thumbnail generation. Built with React frontend and Express backend, the application features rate limiting, real-time generation tracking, and a modern UI with shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured error handling
- **Middleware**: Custom logging, JSON parsing, and error handling middleware
- **Development**: Hot reload with Vite integration for seamless development experience

### Data Storage Solutions
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL with Neon serverless driver
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Development Storage**: In-memory storage implementation for development/testing
- **Session Storage**: connect-pg-simple for PostgreSQL session store

### Database Schema
- **thumbnail_requests**: Stores generation requests with prompt, style, aspect ratio, selected model, reasoning, generated images, and quality metrics
- **daily_usage**: Tracks IP-based rate limiting with daily generation counts
- **Shared Types**: Zod schemas for type-safe validation across frontend and backend

### Authentication and Authorization
- **Rate Limiting**: IP-based daily usage tracking (10 generations per day)
- **Session Management**: Express sessions with PostgreSQL backing
- **No Authentication**: Currently operates without user accounts for simplicity

### AI Integration Architecture
- **Model Selection**: Intelligent AI selector using GPT-4o to analyze prompts and choose optimal model
- **Supported Models**: DALL-E 3, Midjourney, and Stable Diffusion
- **Generation Pipeline**: Prompt enhancement, model-specific optimization, and quality scoring
- **OpenAI Integration**: Primary implementation using OpenAI API with DALL-E 3

## External Dependencies

### AI Services
- **OpenAI API**: Primary AI service for model selection (GPT-4o) and image generation (DALL-E 3)
- **Planned Integrations**: Midjourney API and Stable Diffusion API for complete model coverage

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Alternative Support**: Standard PostgreSQL connections via environment variables

### Development Tools
- **Replit Integration**: Custom Vite plugins for Replit environment including cartographer and runtime error overlay
- **Font Services**: Google Fonts integration for typography (Architects Daughter, DM Sans, Fira Code, Geist Mono)

### UI and Styling
- **Radix UI**: Comprehensive primitive components for accessibility and functionality
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing
- **Lucide React**: Icon library for consistent iconography
- **FontAwesome**: Additional icon support via CDN

### Build and Development
- **Vite**: Fast build tool and development server
- **ESBuild**: Backend bundling for production builds
- **TypeScript**: Type checking and compilation
- **TSX**: TypeScript execution for development server